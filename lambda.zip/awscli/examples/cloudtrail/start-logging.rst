**To start logging for a trail**

The following ``start-logging`` command turns on logging for ``Trail1``::

  aws cloudtrail start-logging --name Trail1
